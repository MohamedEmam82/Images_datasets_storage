# Sign Language Detection > 2024-08-27 6:24am
https://universe.roboflow.com/mohamed-emam/sign-language-detection-sgwlv

Provided by a Roboflow user
License: CC BY 4.0

